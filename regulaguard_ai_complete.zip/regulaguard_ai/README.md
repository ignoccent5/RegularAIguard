# RegulaGuard AI 🛡️

Risk, Fraud & Regulatory Intelligence Copilot — runnable MVP.

## What it includes

- Explainable transaction risk scoring (0–100)
- Isolation Forest anomaly detection
- Fraud/risk alerts
- Investigation case management
- Regulatory document upload
- Local TF-IDF regulatory search
- Streamlit dashboard
- FastAPI REST API
- Sample transaction dataset
- No API key required

> **Important:** This is a demonstration/portfolio project. It is not a production
> AML, fraud, legal, or regulatory compliance system. Do not use it to make
> consequential decisions without appropriate validation, governance, security,
> model-risk controls, and human review.

## 1. Create a virtual environment

### Windows

```powershell
python -m venv .venv
.venv\Scripts\activate
```

### macOS/Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
```

## 2. Install dependencies

```bash
pip install -r requirements.txt
```

## 3. Start the dashboard

From the project root:

```bash
streamlit run frontend/app.py
```

Open the local URL shown by Streamlit.

## 4. Start the API

In a second terminal:

```bash
uvicorn backend.main:app --reload
```

API docs:

```text
http://127.0.0.1:8000/docs
```

## 5. Test the API

```bash
curl http://127.0.0.1:8000/health
```

Get transactions:

```bash
curl http://127.0.0.1:8000/api/transactions
```

Get alerts:

```bash
curl http://127.0.0.1:8000/api/alerts
```

## 6. Regulatory intelligence

Place approved PDF/TXT/MD documents in:

```text
documents/regulations/
```

Or upload them from the Regulatory Copilot page.

The MVP uses TF-IDF retrieval. For a stronger production/hackathon version,
replace it with embeddings + a vector database + a grounded LLM/RAG pipeline.

## 7. Main demo flow

1. Open Executive Dashboard.
2. Show the high-risk transactions.
3. Open Fraud Alerts.
4. Open a critical alert.
5. Create an Investigation Case.
6. Open Investigator.
7. Update the case status and notes.
8. Open Regulatory Copilot.
9. Upload a regulatory PDF/TXT/MD.
10. Ask a compliance question.
11. Return to the dashboard and show the complete risk-to-investigation workflow.

## Architecture

```text
Transactions ──┐
               ├──> Risk/Fraud Engine ──> Alerts ──> Investigator
Regulations ───┤
               └──> Regulatory Search ──> Copilot
                         │
                         └──> Evidence / Sources
```

## Suggested production upgrades

- PostgreSQL + pgvector
- OAuth2 / SSO / RBAC
- Real regulatory feeds from approved sources
- Entity resolution / knowledge graph
- Graph-based fraud detection
- LLM with grounded RAG and citations
- Model monitoring and drift detection
- Audit logging
- PII masking/tokenization
- Human approval gates
- Case workflow integration
- SIEM/KYC/transaction-monitoring integrations
- Regulatory versioning and effective-date tracking
