"""
Fraud and anomaly detection engine.
This is a demo decision-support engine, not a production AML/fraud model.
"""

from __future__ import annotations
import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest


REQUIRED = [
    "transaction_id", "customer_id", "amount", "country",
    "device_changed", "new_beneficiary", "failed_logins",
    "hour", "transaction_count_24h"
]


def prepare_transactions(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    for col in REQUIRED:
        if col not in df.columns:
            raise ValueError(f"Missing required column: {col}")

    numeric = [
        "amount", "failed_logins", "hour", "transaction_count_24h"
    ]
    for c in numeric:
        df[c] = pd.to_numeric(df[c], errors="coerce").fillna(0)

    for c in ["device_changed", "new_beneficiary"]:
        if df[c].dtype == object:
            df[c] = (
                df[c].astype(str).str.strip().str.lower()
                .map({"yes": 1, "true": 1, "1": 1, "no": 0, "false": 0, "0": 0})
                .fillna(0)
            )
        else:
            df[c] = pd.to_numeric(df[c], errors="coerce").fillna(0).clip(0, 1)

    df["country"] = df["country"].fillna("UNKNOWN").astype(str)
    return df


def detect_anomalies(df: pd.DataFrame) -> pd.DataFrame:
    df = prepare_transactions(df)

    features = df[
        ["amount", "device_changed", "new_beneficiary",
         "failed_logins", "hour", "transaction_count_24h"]
    ].copy()

    # Robust log transform for highly skewed transaction amounts.
    features["amount"] = np.log1p(features["amount"].clip(lower=0))

    if len(df) >= 10:
        model = IsolationForest(
            n_estimators=150,
            contamination=min(0.12, max(0.03, 5 / len(df))),
            random_state=42
        )
        pred = model.fit_predict(features)
        anomaly_score = -model.decision_function(features)
        # Normalize approximately to 0-100.
        lo, hi = anomaly_score.min(), anomaly_score.max()
        if hi > lo:
            anomaly_score = (anomaly_score - lo) / (hi - lo) * 100
        else:
            anomaly_score = np.zeros(len(df))
        df["ml_anomaly"] = (pred == -1).astype(int)
        df["ml_anomaly_score"] = anomaly_score.round(1)
    else:
        df["ml_anomaly"] = 0
        df["ml_anomaly_score"] = 0.0

    return df
