"""
Explainable risk scoring engine.
Weights are intentionally transparent for the demo.
"""

import pandas as pd
from .fraud_engine import detect_anomalies


HIGH_RISK_COUNTRIES = {
    "COUNTRY_X", "COUNTRY_Y"
}


def score_row(row) -> tuple[float, list[str]]:
    score = 0.0
    reasons = []

    amount = float(row.get("amount", 0))
    if amount >= 500000:
        score += 25
        reasons.append("Very high transaction amount")
    elif amount >= 200000:
        score += 15
        reasons.append("High transaction amount")
    elif amount >= 100000:
        score += 8
        reasons.append("Elevated transaction amount")

    if int(row.get("new_beneficiary", 0)) == 1:
        score += 18
        reasons.append("New beneficiary")

    if int(row.get("device_changed", 0)) == 1:
        score += 15
        reasons.append("Device changed")

    failed = int(row.get("failed_logins", 0))
    if failed >= 5:
        score += 15
        reasons.append("Multiple failed login attempts")
    elif failed >= 2:
        score += 8
        reasons.append("Repeated failed login attempts")

    velocity = int(row.get("transaction_count_24h", 0))
    if velocity >= 15:
        score += 15
        reasons.append("High transaction velocity")
    elif velocity >= 8:
        score += 8
        reasons.append("Elevated transaction velocity")

    hour = int(row.get("hour", 12))
    if hour <= 5:
        score += 7
        reasons.append("Transaction at unusual hour")

    if str(row.get("country", "")).upper() in HIGH_RISK_COUNTRIES:
        score += 10
        reasons.append("Configured high-risk geography")

    ml = float(row.get("ml_anomaly_score", 0))
    if ml >= 70:
        score += 15
        reasons.append("ML anomaly signal is high")
    elif ml >= 45:
        score += 8
        reasons.append("ML anomaly signal is elevated")

    return min(round(score, 1), 100.0), reasons


def enrich_risk(df: pd.DataFrame) -> pd.DataFrame:
    df = detect_anomalies(df)

    scores, reasons, levels = [], [], []
    for _, row in df.iterrows():
        score, why = score_row(row)
        scores.append(score)
        reasons.append(why)

        if score >= 80:
            level = "CRITICAL"
        elif score >= 60:
            level = "HIGH"
        elif score >= 35:
            level = "MEDIUM"
        else:
            level = "LOW"
        levels.append(level)

    df["risk_score"] = scores
    df["risk_level"] = levels
    df["risk_reasons"] = reasons
    df["alert"] = df["risk_score"] >= 60
    return df
