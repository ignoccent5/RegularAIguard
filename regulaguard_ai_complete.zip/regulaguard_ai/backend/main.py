from pathlib import Path
import pandas as pd
from fastapi import FastAPI, UploadFile, File, HTTPException
from pydantic import BaseModel

from .database import init_db, create_case, list_cases, update_case
from .risk_engine import enrich_risk
from .regulatory_search import answer_regulatory_question

app = FastAPI(
    title="RegulaGuard AI API",
    version="1.0.0",
    description="Risk, fraud and regulatory intelligence copilot MVP."
)

init_db()

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
DEFAULT_CSV = DATA_DIR / "transactions.csv"


class CaseRequest(BaseModel):
    transaction_id: str
    customer_id: str
    risk_score: float
    risk_level: str
    investigator: str = "Unassigned"
    notes: str = ""


class CaseUpdate(BaseModel):
    status: str | None = None
    investigator: str | None = None
    notes: str | None = None


class RegulatoryQuery(BaseModel):
    query: str


def load_and_score(path=DEFAULT_CSV):
    df = pd.read_csv(path)
    return enrich_risk(df)


@app.get("/")
def root():
    return {"name": "RegulaGuard AI", "status": "online"}


@app.get("/health")
def health():
    return {"status": "healthy"}


@app.get("/api/transactions")
def transactions():
    df = load_and_score()
    safe = df.copy()
    safe["risk_reasons"] = safe["risk_reasons"].apply(lambda x: "; ".join(x))
    return safe.to_dict(orient="records")


@app.get("/api/alerts")
def alerts():
    df = load_and_score()
    df = df[df["alert"] == True].copy()
    df["risk_reasons"] = df["risk_reasons"].apply(lambda x: "; ".join(x))
    return df.sort_values("risk_score", ascending=False).to_dict(orient="records")


@app.post("/api/cases")
def create_case_api(req: CaseRequest):
    ref = create_case(
        req.transaction_id, req.customer_id, req.risk_score,
        req.risk_level, req.investigator, req.notes
    )
    return {"case_ref": ref, "status": "created"}


@app.get("/api/cases")
def cases():
    return list_cases()


@app.patch("/api/cases/{case_ref}")
def update_case_api(case_ref: str, req: CaseUpdate):
    update_case(case_ref, req.status, req.investigator, req.notes)
    return {"case_ref": case_ref, "status": "updated"}


@app.post("/api/regulatory/query")
def regulatory_query(req: RegulatoryQuery):
    return answer_regulatory_question(req.query)


@app.post("/api/transactions/upload")
async def upload_transactions(file: UploadFile = File(...)):
    if not file.filename.lower().endswith(".csv"):
        raise HTTPException(400, "Only CSV files are supported.")
    DATA_DIR.mkdir(exist_ok=True)
    target = DATA_DIR / "transactions.csv"
    target.write_bytes(await file.read())
    return {"message": "Transaction dataset uploaded successfully."}
