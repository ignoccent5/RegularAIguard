"""
Lightweight local regulatory intelligence search.
Supports TXT, MD and PDF files in documents/regulations.
It uses TF-IDF similarity, so no API key is required.
"""

from pathlib import Path
import re
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

ROOT = Path(__file__).resolve().parent.parent
REG_DIR = ROOT / "documents" / "regulations"


def load_documents():
    docs = []
    REG_DIR.mkdir(parents=True, exist_ok=True)

    for path in REG_DIR.rglob("*"):
        if not path.is_file():
            continue

        text = ""
        if path.suffix.lower() in {".txt", ".md"}:
            text = path.read_text(encoding="utf-8", errors="ignore")
        elif path.suffix.lower() == ".pdf":
            try:
                from pypdf import PdfReader
                reader = PdfReader(str(path))
                text = "\n".join((p.extract_text() or "") for p in reader.pages)
            except Exception:
                continue

        if text.strip():
            docs.append({
                "name": path.name,
                "path": str(path),
                "text": re.sub(r"\s+", " ", text).strip()
            })
    return docs


def search_regulations(query, top_k=5):
    docs = load_documents()
    if not docs:
        return []

    corpus = [d["text"] for d in docs]
    vectorizer = TfidfVectorizer(
        stop_words="english",
        ngram_range=(1, 2),
        max_features=10000
    )
    matrix = vectorizer.fit_transform(corpus + [query])
    similarities = cosine_similarity(matrix[-1], matrix[:-1]).flatten()

    indices = similarities.argsort()[::-1][:top_k]
    results = []
    for i in indices:
        results.append({
            "name": docs[i]["name"],
            "score": round(float(similarities[i]), 3),
            "snippet": docs[i]["text"][:1000]
        })
    return results


def answer_regulatory_question(query):
    results = search_regulations(query, top_k=3)
    if not results:
        return {
            "answer": "No regulatory documents are available. Add PDF, TXT or MD files to documents/regulations.",
            "sources": []
        }

    best = results[0]
    answer = (
        f"Based on the local regulatory knowledge base, the strongest matching "
        f"source is '{best['name']}'. Relevant content: {best['snippet']}"
    )
    return {"answer": answer, "sources": results}
