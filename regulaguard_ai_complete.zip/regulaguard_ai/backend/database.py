import sqlite3
from pathlib import Path
from datetime import datetime

DB_PATH = Path(__file__).resolve().parent.parent / "storage" / "regulaguard.db"


def connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = connect()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS cases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            case_ref TEXT UNIQUE,
            transaction_id TEXT,
            customer_id TEXT,
            risk_score REAL,
            risk_level TEXT,
            status TEXT DEFAULT 'Open',
            investigator TEXT DEFAULT 'Unassigned',
            notes TEXT DEFAULT '',
            created_at TEXT
        )
    """)
    conn.commit()
    conn.close()


def create_case(transaction_id, customer_id, risk_score, risk_level,
                investigator="Unassigned", notes=""):
    conn = connect()
    ref = f"RG-{datetime.now().strftime('%Y%m%d%H%M%S%f')[:-3]}"
    conn.execute("""
        INSERT INTO cases
        (case_ref, transaction_id, customer_id, risk_score, risk_level,
         status, investigator, notes, created_at)
        VALUES (?, ?, ?, ?, ?, 'Open', ?, ?, ?)
    """, (
        ref, transaction_id, customer_id, risk_score, risk_level,
        investigator, notes, datetime.now().isoformat(timespec="seconds")
    ))
    conn.commit()
    conn.close()
    return ref


def list_cases():
    conn = connect()
    rows = conn.execute(
        "SELECT * FROM cases ORDER BY id DESC"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def update_case(case_ref, status=None, investigator=None, notes=None):
    conn = connect()
    fields, values = [], []
    if status is not None:
        fields.append("status=?"); values.append(status)
    if investigator is not None:
        fields.append("investigator=?"); values.append(investigator)
    if notes is not None:
        fields.append("notes=?"); values.append(notes)

    if fields:
        values.append(case_ref)
        conn.execute(
            f"UPDATE cases SET {', '.join(fields)} WHERE case_ref=?",
            values
        )
        conn.commit()
    conn.close()
