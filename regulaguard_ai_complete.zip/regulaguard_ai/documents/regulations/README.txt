Place approved regulatory PDF, TXT, or MD documents in this folder.
The Streamlit Regulatory Copilot will index them locally.