import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd
import streamlit as st

from backend.risk_engine import enrich_risk
from backend.database import init_db, create_case, list_cases, update_case
from backend.regulatory_search import answer_regulatory_question

ROOT = Path(__file__).resolve().parent.parent
DATA_FILE = ROOT / "data" / "transactions.csv"
REG_DIR = ROOT / "documents" / "regulations"

st.set_page_config(
    page_title="RegulaGuard AI",
    page_icon="🛡️",
    layout="wide"
)

init_db()

st.markdown("""
<style>
.main-title {font-size: 2.5rem; font-weight: 800;}
.subtitle {font-size: 1.05rem; opacity: .75;}
.card {padding: 18px; border: 1px solid #ddd; border-radius: 14px;}
</style>
""", unsafe_allow_html=True)

st.markdown('<div class="main-title">🛡️ RegulaGuard AI</div>', unsafe_allow_html=True)
st.markdown(
    '<div class="subtitle">Risk, Fraud & Regulatory Intelligence Copilot — MVP</div>',
    unsafe_allow_html=True
)

@st.cache_data
def load_data():
    return pd.read_csv(DATA_FILE)

def get_scored():
    return enrich_risk(load_data())

# Sidebar
st.sidebar.header("Navigation")
page = st.sidebar.radio(
    "Open",
    ["Executive Dashboard", "Fraud Alerts", "Investigator", "Regulatory Copilot", "Data"]
)

if page == "Executive Dashboard":
    df = get_scored()

    st.subheader("Executive Risk Overview")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Transactions", len(df))
    c2.metric("Critical", int((df.risk_level == "CRITICAL").sum()))
    c3.metric("High Risk", int((df.risk_level == "HIGH").sum()))
    c4.metric("Open Alerts", int(df.alert.sum()))

    st.divider()
    left, right = st.columns(2)

    with left:
        st.subheader("Risk Distribution")
        st.bar_chart(df["risk_level"].value_counts())

    with right:
        st.subheader("Top Risk Transactions")
        cols = ["transaction_id", "customer_id", "amount", "risk_score", "risk_level"]
        st.dataframe(
            df.sort_values("risk_score", ascending=False)[cols].head(10),
            use_container_width=True,
            hide_index=True
        )

    st.subheader("Risk Score Trend")
    chart_df = df[["transaction_id", "risk_score"]].set_index("transaction_id")
    st.line_chart(chart_df)

elif page == "Fraud Alerts":
    st.subheader("🚨 Fraud & Risk Alerts")
    df = get_scored()
    alerts = df[df.alert].sort_values("risk_score", ascending=False)

    if alerts.empty:
        st.success("No alerts detected.")
    else:
        for _, row in alerts.iterrows():
            icon = "🔴" if row.risk_score >= 80 else "🟠"
            with st.expander(
                f"{icon} {row.transaction_id} — {row.risk_level} — {row.risk_score}/100"
            ):
                a, b, c = st.columns(3)
                a.write(f"**Customer:** {row.customer_id}")
                b.write(f"**Amount:** ₹{row.amount:,.2f}")
                c.write(f"**Country:** {row.country}")

                st.markdown("**Why was this flagged?**")
                for reason in row.risk_reasons:
                    st.write(f"• {reason}")

                if st.button(
                    "Create Investigation Case",
                    key=f"case_{row.transaction_id}"
                ):
                    ref = create_case(
                        row.transaction_id,
                        row.customer_id,
                        float(row.risk_score),
                        row.risk_level,
                        "Unassigned",
                        "; ".join(row.risk_reasons)
                    )
                    st.success(f"Case created: {ref}")

elif page == "Investigator":
    st.subheader("🕵️ Investigator Workspace")
    cases = list_cases()

    if not cases:
        st.info("No investigation cases yet. Create one from Fraud Alerts.")
    else:
        case_df = pd.DataFrame(cases)
        st.dataframe(case_df, use_container_width=True, hide_index=True)

        st.divider()
        refs = [c["case_ref"] for c in cases]
        selected = st.selectbox("Select Case", refs)
        case = next(c for c in cases if c["case_ref"] == selected)

        st.markdown(f"### {case['case_ref']}")
        x, y, z = st.columns(3)
        x.metric("Risk", f"{case['risk_score']}/100")
        y.metric("Level", case["risk_level"])
        z.metric("Status", case["status"])

        st.write(f"**Transaction:** {case['transaction_id']}")
        st.write(f"**Customer:** {case['customer_id']}")
        st.write(f"**Created:** {case['created_at']}")
        st.write(f"**Current investigator:** {case['investigator']}")

        new_status = st.selectbox(
            "Status", ["Open", "Under Review", "Escalated", "Closed"],
            index=["Open", "Under Review", "Escalated", "Closed"].index(case["status"])
        )
        investigator = st.text_input(
            "Investigator", value=case["investigator"]
        )
        notes = st.text_area("Investigation Notes", value=case["notes"])

        if st.button("Update Case"):
            update_case(selected, new_status, investigator, notes)
            st.success("Case updated.")
            st.rerun()

elif page == "Regulatory Copilot":
    st.subheader("📚 Regulatory Intelligence Copilot")
    st.write(
        "Search the local regulatory knowledge base. Add PDF, TXT or MD files "
        "to `documents/regulations/`."
    )

    REG_DIR.mkdir(parents=True, exist_ok=True)
    uploaded = st.file_uploader(
        "Upload a regulatory document",
        type=["pdf", "txt", "md"]
    )
    if uploaded:
        (REG_DIR / uploaded.name).write_bytes(uploaded.getbuffer())
        st.success(f"Added {uploaded.name}. You can query it below.")

    query = st.text_area(
        "Ask a regulatory question",
        placeholder="What requirements apply to high-risk transactions?"
    )

    if st.button("Ask RegulaGuard") and query.strip():
        result = answer_regulatory_question(query)
        st.markdown("### AI Regulatory Response")
        st.write(result["answer"])

        st.markdown("### Sources")
        for source in result["sources"]:
            st.write(
                f"**{source['name']}** — similarity: {source['score']}"
            )
            st.caption(source["snippet"][:700])

    st.info(
        "Demo note: this MVP uses local document retrieval. "
        "For production compliance use, connect it to approved regulatory "
        "sources and require human validation."
    )

elif page == "Data":
    st.subheader("📊 Transaction Data")
    df = get_scored()

    uploaded = st.file_uploader(
        "Replace transaction dataset",
        type=["csv"]
    )
    if uploaded:
        DATA_FILE.write_bytes(uploaded.getbuffer())
        st.cache_data.clear()
        st.success("Dataset replaced. Refreshing...")
        st.rerun()

    st.dataframe(df, use_container_width=True, hide_index=True)

    st.download_button(
        "Download scored results",
        df.to_csv(index=False),
        "regulaguard_scored_transactions.csv",
        "text/csv"
    )
